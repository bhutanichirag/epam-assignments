# Khyati-Clean-Code-and-Serialization
EPAM  4th task
