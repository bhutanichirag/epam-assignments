# Khyati-Design-Patterns
EPAM TASK
