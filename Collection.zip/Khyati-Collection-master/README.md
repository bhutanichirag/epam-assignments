# Khyati-Collection
EPAM Collection task
