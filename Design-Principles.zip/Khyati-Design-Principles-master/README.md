# Khyati-Design-Principles
EPAM Third Task
